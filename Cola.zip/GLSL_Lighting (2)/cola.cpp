#include "cola.h"


void Cola::DibujarCola(float Angulo, float x, float y, float z, int n) {


	glPushMatrix();

	glTranslatef(x, y, z);
	


	glRotatef((GLfloat)Angulo, 1, 0, 5.0);

	glTranslatef(0.2, 0.4, 2); glPushMatrix();

	glScalef(3.0, 0.4, 0.5);

	glutSolidCube(1.0);


	glPopMatrix();


	for (int i = 0; i< n; i++){

		glTranslatef(-0.1, 0.3, 0.4);

		glRotatef((GLfloat)Angulo, 0.0, 0.1, 1);

		glTranslatef(-1, 1, 0);

		glPushMatrix();

		glScalef(2.0, 0.3, 1.0);

		glutSolidCube(0.6);
		
		glutSolidSphere(3, 5, 3);


		glPopMatrix();
	}


	glPopMatrix();



}